LaTeX report source, vector figures and numerical tables.
Build in this directory using a standard LaTeX installation:
  pdflatex -interaction=nonstopmode -halt-on-error Environment_Controller_Tutorial.tex
  pdflatex -interaction=nonstopmode -halt-on-error Environment_Controller_Tutorial.tex
No Simulink rerun is needed to rebuild this PDF.
See the report for model-map limits and the 200-point test allocation.
